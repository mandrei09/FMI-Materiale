// /Mihai Andrei Alexandru grupa 141 Varianta A
const express=require('express');
const app=express();

app.use('/post',express.urlencoded({extended:true}));

app.get("/p4.html", function(req,res){
	res.sendFile(__dirname+ "/p4.html");
});

app.post("/post",function(req,res){

let arr = [];
	console.log(req.body);
	//
	res.send(arr);
});

app.listen(7000, function(){console.log("Serverul a pornit");});

